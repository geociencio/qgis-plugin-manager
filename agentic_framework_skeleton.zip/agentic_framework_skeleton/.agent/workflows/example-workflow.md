---
description: A template workflow to demonstrate structure
agent: QA Engineer
skills: [example-skill]
validation: |
  - Verify that this is useful
  - Confirm understanding
---

# Example Workflow

1.  **Step One**:
    
    🤖 **Agent Action**: Use skill **example-skill** to understand context.
    
    Do something important here.

2.  **Step Two**:
    
    Execute commands:
    ```bash
    echo "Running workflow..."
    ```
