# Definition of Agents

## Roles
- **Senior Architect**: Responsible for high-level design, refactoring, and structural decisions.
- **QA Engineer**: Responsible for testing, pipelines, and releases.
- **Developer**: Responsible for implementing features and fixing bugs.

## Skill Matrix
| Skill | Trigger | Primary Agent |
|-------|---------|------------------|
| example-skill | example, demo | QA Engineer |
