---
name: example-skill
description: A template skill to demonstrate the structure
trigger: when learning how to create skills
---

# Example Skill Template

## Core Knowledge
Explain the concept or technology here.

## Validation Checklist
- [ ] Item 1
- [ ] Item 2

## Common Commands
```bash
echo "Hello World"
```
